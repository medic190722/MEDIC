package com.kh.medic.vacation.model;

public class VacationException extends RuntimeException{

	public VacationException() {
		super();
	}
	
	
	public VacationException(String message) {
		super(message);
	}
	
}
