package com.kh.medic.equipment.model;

public class EquipmentException extends RuntimeException{
	public EquipmentException() {
		super();
	}
	
	public EquipmentException(String message) {
		super(message);
	}
}
