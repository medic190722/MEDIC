package com.kh.medic.medicine.model;

public class MedicineException extends RuntimeException{
	public MedicineException() {
		super();
	}
	
	public MedicineException(String message) {
		super(message);
	}
}
